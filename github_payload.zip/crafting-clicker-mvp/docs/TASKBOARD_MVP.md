# Task-Board MVP: Crafting Clicker

## 0) Leitregeln gegen Diskrepanzen

1. **Single Source of Truth**
- Alle Regeln (Kosten, Unlocks, Punkte, Level) nur in `packages/core`.
- `apps/web` liest nur State und dispatcht Actions.

2. **Contract First**
- Vor UI-Task muss API im Core stehen (`GameAction`, `GameState`, Selektoren).
- Jede neue UI-Funktion braucht zuerst einen Core-Contract oder Selector.

3. **No Parallel Logic**
- Keine doppelten Berechnungen in Components (maximal Anzeigeformate).

4. **Versioned Save**
- Persistenz nur via `sanitizeState` + `version`.
- Schema-Updates laufen ueber Migration-Task, nicht ad hoc.

5. **Done nur mit Abnahmecheck**
- Jeder Task hat `Input`, `Output`, `Abhaengigkeiten`, `DoD`.

## 1) Zielstruktur (bereits vorbereitet)

- `packages/core/src/domain/*`: Typen, Konstanten
- `packages/core/src/recipes/*`: Rezeptkatalog
- `packages/core/src/progression/*`: Levelkurve
- `packages/core/src/engine/*`: Reducer, Selektoren, Persistence
- `apps/web/src/store/*`: Zustand-Store (nur Action-Wiring)
- `apps/web/src/components/*`: Reine Darstellung
- `apps/web/src/hooks/*`: Device/UX Hooks
- `apps/web/src/styles/*`: Design Tokens + Animation

## 2) Sequenzierter Delivery-Plan (Tag 1 bis Tag 14)

## Tag 1 - Core-Fundament finalisieren

### Task 1.1 Domain Contracts schliessen
- **Zeitpunkt**: Start Tag 1
- **Schreiben in**: `packages/core/src/domain/types.ts`
- **Basiert auf**: Produktscope (Ressourcen + Itemkette)
- **Bereitet vor**: Reducer, Persistenz, UI-Rendering
- **Wie schreiben**:
  - Nur string unions fuer IDs.
  - `GameAction` explizit als discriminated union.
  - Niemals `any` in Core.
- **DoD**:
  - Alle Entitaeten typisiert.
  - Kein UI-spezifischer Typ im Core.

### Task 1.2 Rezeptkatalog + Index
- **Zeitpunkt**: nach 1.1
- **Schreiben in**: `packages/core/src/recipes/catalog.ts`
- **Abhaengigkeit**: 1.1
- **Bereitet vor**: Crafting, Unlocks, Economy-Balance
- **Wie schreiben**:
  - IDs stabil halten (`snake_case`), nie nachtraeglich umbenennen.
  - `RECIPE_INDEX` erzeugen, damit Reducer O(1)-Lookup nutzt.
- **DoD**:
  - Mind. 6 Rezepte in 5 Tiers.
  - Unlock-Bedingungen vorhanden.

### Task 1.3 Reducer + Selektoren
- **Zeitpunkt**: nach 1.2
- **Schreiben in**:
  - `packages/core/src/engine/reducer.ts`
  - `packages/core/src/engine/selectors.ts`
- **Abhaengigkeit**: 1.1, 1.2
- **Bereitet vor**: Store-Integration Web
- **Wie schreiben**:
  - Aktionen pure und deterministisch.
  - `refreshUnlocks` zentral nach statusaendernden Aktionen.
  - Kein Side-Effect im Reducer.
- **DoD**:
  - `GATHER`, `CRAFT`, `BULK_CRAFT`, `HYDRATE`, `RESET` laufen.
  - Invalides Rezept aendert State nicht.

### Task 1.4 Persistence Contract
- **Zeitpunkt**: Ende Tag 1
- **Schreiben in**: `packages/core/src/engine/persistence.ts`
- **Abhaengigkeit**: 1.3
- **Bereitet vor**: Auto-Save, Migrationen
- **Wie schreiben**:
  - `sanitizeState(unknown)` immer fallback-sicher.
  - `version` erzwingen.
- **DoD**:
  - Corrupt Save fuehrt nicht zum Crash.

## Tag 2 - Web-Store und App-Shell

### Task 2.1 Zustand Store anbinden
- **Zeitpunkt**: Start Tag 2
- **Schreiben in**: `apps/web/src/store/useGameStore.ts`
- **Abhaengigkeit**: Tag 1 komplett
- **Bereitet vor**: alle Panels
- **Wie schreiben**:
  - Store hat nur orchestration (dispatch, persist hooks).
  - Action-Mapping 1:1 auf `GameAction`.
- **DoD**:
  - UI kann gather/craft/reset/save/load ueber Store.

### Task 2.2 App Shell + Layout Grid
- **Zeitpunkt**: nach 2.1
- **Schreiben in**:
  - `apps/web/src/app/App.tsx`
  - `apps/web/src/styles/global.css`
- **Abhaengigkeit**: 2.1
- **Bereitet vor**: komponentenweise Lieferung
- **Wie schreiben**:
  - Mobile first (1 Spalte), ab Breakpoint 2 Spalten.
  - Topbar fixiert Hauptmetriken.
- **DoD**:
  - Desktop + Mobile sinnvoll bedienbar.

## Tag 3 - Feature Panels

### Task 3.1 Resource Panel
- **Zeitpunkt**: Start Tag 3
- **Schreiben in**: `apps/web/src/components/ResourcePanel.tsx`
- **Abhaengigkeit**: 2.1
- **Bereitet vor**: Ressourcengenerierung, UX-Feedback
- **Wie schreiben**:
  - Pro Resource dedizierter Button + Count.
  - Touch target >= 44px.
- **DoD**:
  - Jeder Klick erhoeht korrekte Resource.

### Task 3.2 Crafting Panel
- **Zeitpunkt**: nach 3.1
- **Schreiben in**: `apps/web/src/components/CraftingPanel.tsx`
- **Abhaengigkeit**: 3.1, 1.3
- **Bereitet vor**: Haupt-Gameplay
- **Wie schreiben**:
  - Nur `availableRecipes()` rendern.
  - Button disable anhand `canCraft`.
  - Bulk-Craft nur als Action, keine for-loop im UI.
- **DoD**:
  - Crafting-Status entspricht Core.

### Task 3.3 Inventory + Event Feed
- **Zeitpunkt**: Ende Tag 3
- **Schreiben in**:
  - `apps/web/src/components/InventoryPanel.tsx`
  - `apps/web/src/components/EventFeed.tsx`
- **Abhaengigkeit**: 3.2
- **Bereitet vor**: Transparenz und Debugbarkeit
- **DoD**:
  - Inventar entspricht exakt Store-State.
  - Eventfeed capped (max 30).

## Tag 4 - Animationen und Grafiksystem

### Task 4.1 Motion-Guidelines technisch verankern
- **Zeitpunkt**: Start Tag 4
- **Schreiben in**: `apps/web/src/hooks/useReducedMotion.ts`
- **Abhaengigkeit**: Tag 3 fertig
- **Bereitet vor**: barrierearme Animationen
- **Wie schreiben**:
  - motion zentral steuerbar.
- **DoD**:
  - `prefers-reduced-motion` schaltet Bewegungen runter.

### Task 4.2 Visual Tokens und komponentenweite Konsistenz
- **Zeitpunkt**: nach 4.1
- **Schreiben in**: `apps/web/src/styles/global.css`
- **Abhaengigkeit**: 4.1
- **Bereitet vor**: schnelle Theme-Iteration
- **Wie schreiben**:
  - Farben, Radius, Schatten als Variablen.
  - Keine Hardcoded Farben in Components.
- **DoD**:
  - Theme in <30 Minuten austauschbar.

### Task 4.3 Grafik-Integration (Asset Pipeline)
- **Zeitpunkt**: Ende Tag 4
- **Schreiben in**: `apps/web/src/assets/*`
- **Abhaengigkeit**: 4.2
- **Bereitet vor**: hochwertigere Optik
- **Wie schreiben**:
  - Icons SVG/WebP, klare Benennung `resource-cloth.svg` etc.
  - Asset-Mapping in separater Datei.
- **DoD**:
  - Keine ungenutzten Assets im Bundle.

## Tag 5 - Datenintegritaet, QA, Balancing

### Task 5.1 Balancing Table externisieren
- **Zeitpunkt**: Start Tag 5
- **Schreiben in**: `packages/core/src/recipes/catalog.ts` und `economy.ts`
- **Abhaengigkeit**: Tag 4
- **Bereitet vor**: schnellere Iteration mit LLM
- **Wie schreiben**:
  - Punktwerte und Kosten in klarer Tabelle.
  - Keine Magic Numbers im Reducer.
- **DoD**:
  - 20-30 Minuten Session fuehlt progressiv an.

### Task 5.2 Integrations-Checks
- **Zeitpunkt**: nach 5.1
- **Schreiben in**: `docs/QA_CHECKLIST.md`
- **Abhaengigkeit**: 5.1
- **Bereitet vor**: stabile MVP-Auslieferung
- **DoD**:
  - save/load, reset, unlock, bulk craft validiert.

## Tag 6 - App-Vorbereitung (ohne App-Implementierung)

### Task 6.1 Platform Adapter Contract
- **Zeitpunkt**: kompletter Tag 6
- **Schreiben in**: `packages/core/src/platform/*`
- **Abhaengigkeit**: Tag 5
- **Bereitet vor**: Expo-Port ohne Core-Aenderungen
- **Wie schreiben**:
  - Interface fuer Storage und Telemetrie definieren.
  - Web nutzt localStorage Adapter; Mobile spaeter AsyncStorage Adapter.
- **DoD**:
  - Kein direkter Browser-Zugriff mehr im Core.

## Tag 7 - Release Hardening

### Task 7.1 MVP Release Cut
- **Zeitpunkt**: Start Tag 7
- **Schreiben in**: `docs/RELEASE_NOTES_MVP.md`
- **Abhaengigkeit**: Tag 6
- **Bereitet vor**: Demo/Go-Live
- **DoD**:
  - Known Issues dokumentiert.
  - Scope Freeze aktiv.

### Task 7.2 Post-MVP Backlog sortieren
- **Zeitpunkt**: Ende Tag 7
- **Schreiben in**: `docs/BACKLOG_POST_MVP.md`
- **Abhaengigkeit**: 7.1
- **Bereitet vor**: kontrolliertes Wachstum
- **DoD**:
  - Features nach ROI/Risiko sortiert.

## Tag 8 - Single-Daten-Basis (Web only)

### Task 8.1 Datenmodell fuer zentrale Persistenz einfrieren
- **Zeitpunkt**: Start Tag 8
- **Schreiben in**:
  - `packages/core/src/domain/types.ts`
  - `docs/DATA_CONTRACT.md`
- **Abhaengigkeit**: Tag 7
- **Bereitet vor**: konfliktfreie DB-Anbindung
- **Wie schreiben**:
  - Ein eindeutiges Spieler-Dokument (`player_state`) als Hauptobjekt.
  - Keine gesplitteten Teilmodelle ohne Versionierung.
- **DoD**:
  - JSON-Schema fuer Save-State versioniert dokumentiert.

### Task 8.2 Repository-Layer statt direkter Speicheraufrufe
- **Zeitpunkt**: nach 8.1
- **Schreiben in**:
  - `packages/core/src/platform/repository.ts`
  - `apps/web/src/store/useGameStore.ts`
- **Abhaengigkeit**: 8.1
- **Bereitet vor**: lokal/remote austauschbar ohne UI-Refactor
- **Wie schreiben**:
  - `loadState`, `saveState`, `syncState` als Interface.
  - Store kennt nur Repository, nicht Implementierungsdetails.
- **DoD**:
  - Kein direkter `localStorage` Zugriff mehr im Store.

## Tag 9 - Offline-First Synchronisierung (Handy-fokussiert)

### Task 9.1 Local-first mit Write-Queue
- **Zeitpunkt**: Start Tag 9
- **Schreiben in**:
  - `apps/web/src/store/syncQueue.ts`
  - `apps/web/src/store/useGameStore.ts`
- **Abhaengigkeit**: Tag 8
- **Bereitet vor**: stabile Nutzung bei schlechtem Netz
- **Wie schreiben**:
  - Jede Mutation lokal sofort anwenden.
  - Queue speichert ausstehende Sync-Operationen.
- **DoD**:
  - Spiel bleibt voll nutzbar ohne Netzwerk.

### Task 9.2 Konfliktstrategie definieren
- **Zeitpunkt**: nach 9.1
- **Schreiben in**:
  - `docs/SYNC_STRATEGY.md`
  - `packages/core/src/engine/merge.ts`
- **Abhaengigkeit**: 9.1
- **Bereitet vor**: Datenkonsistenz bei Mehrgeraete-Nutzung
- **Wie schreiben**:
  - Last-write-wins fuer MVP.
  - spaeter event-basierter Merge vorbereiten.
- **DoD**:
  - deterministische Merge-Regeln dokumentiert und testbar.

## Tag 10 - Mobile Performance Hardening

### Task 10.1 Render- und Recompute-Kosten reduzieren
- **Zeitpunkt**: Start Tag 10
- **Schreiben in**:
  - `apps/web/src/store/useGameStore.ts`
  - `apps/web/src/components/*`
- **Abhaengigkeit**: Tag 9
- **Bereitet vor**: ruckelfreies Spiel auf Midrange-Handys
- **Wie schreiben**:
  - Selektive Store-Subscriptions pro Komponente.
  - Memoization fuer teure Listen.
- **DoD**:
  - Kein Full-Tree-Re-render bei einzelnen Klicks.

### Task 10.2 Asset- und Motion-Budget erzwingen
- **Zeitpunkt**: nach 10.1
- **Schreiben in**:
  - `docs/PERFORMANCE_BUDGET.md`
  - `apps/web/src/styles/global.css`
- **Abhaengigkeit**: 10.1
- **Bereitet vor**: stabile FPS
- **Wie schreiben**:
  - Maximal 1 Key-Animation pro Interaktion.
  - Groessere Assets lazy laden.
- **DoD**:
  - Budgetgrenzen klar dokumentiert und eingehalten.

## Tag 11 - PWA und Handy-Installierbarkeit

### Task 11.1 PWA-Grundlagen
- **Zeitpunkt**: Start Tag 11
- **Schreiben in**:
  - `apps/web/public/manifest.webmanifest`
  - `apps/web/public/icons/*`
  - `apps/web/vite.config.ts`
- **Abhaengigkeit**: Tag 10
- **Bereitet vor**: app-aehnliche Installation
- **Wie schreiben**:
  - Homescreen-Iconsets in mehreren Groessen.
  - sinnvolle Start-URL und Display-Mode.
- **DoD**:
  - App installierbar auf Android Browser.

### Task 11.2 Offline-Caching fuer statische Assets
- **Zeitpunkt**: nach 11.1
- **Schreiben in**:
  - `apps/web/src/sw.ts`
  - Build-Integration in Web-App
- **Abhaengigkeit**: 11.1
- **Bereitet vor**: schneller Start bei wiederholter Nutzung
- **Wie schreiben**:
  - Cache-first nur fuer statische Assets.
  - State-Daten nie blind aus Cache liefern.
- **DoD**:
  - Reload ohne Netz zeigt weiterhin UI.

## Tag 12 - Sicherheit und Integritaet (Web)

### Task 12.1 Input/State-Hardening
- **Zeitpunkt**: Start Tag 12
- **Schreiben in**:
  - `packages/core/src/engine/persistence.ts`
  - `packages/core/src/engine/reducer.ts`
- **Abhaengigkeit**: Tag 11
- **Bereitet vor**: robustere Save-Daten
- **Wie schreiben**:
  - Grenzen fuer numerische Werte (>=0, max cap).
  - Unbekannte Felder ignorieren.
- **DoD**:
  - Manipulierte Saves crashen nicht und korrumpieren nicht.

### Task 12.2 Minimaler Abuse-Schutz
- **Zeitpunkt**: nach 12.1
- **Schreiben in**:
  - `apps/web/src/store/useGameStore.ts`
  - `docs/SECURITY_NOTES.md`
- **Abhaengigkeit**: 12.1
- **Bereitet vor**: kontrollierte Punktespruenge
- **Wie schreiben**:
  - Klick-Rate-Guard nur fuer extremes Spamming.
  - alles transparent dokumentieren.
- **DoD**:
  - kein unfairer Progress durch triviale Exploits.

## Tag 13 - Observability und Live-Betrieb

### Task 13.1 Telemetrie-Hooks
- **Zeitpunkt**: Start Tag 13
- **Schreiben in**:
  - `packages/core/src/platform/telemetry.ts`
  - `apps/web/src/store/useGameStore.ts`
- **Abhaengigkeit**: Tag 12
- **Bereitet vor**: datengetriebenes Balancing
- **Wie schreiben**:
  - Events nur aggregiert (keine sensiblen Rohdaten).
  - Feature-Flag fuer deaktivierbare Telemetrie.
- **DoD**:
  - Session-Metriken fuer Balancing abrufbar.

### Task 13.2 Runtime-Fehlerpfad
- **Zeitpunkt**: nach 13.1
- **Schreiben in**:
  - `apps/web/src/app/ErrorBoundary.tsx`
  - `apps/web/src/app/App.tsx`
- **Abhaengigkeit**: 13.1
- **Bereitet vor**: ausfallsichere User Experience
- **DoD**:
  - Fehlerfall zeigt Recovery-UI statt White-Screen.

## Tag 14 - Stabiler Release-Kandidat

### Task 14.1 End-to-End Smoke-Suite
- **Zeitpunkt**: Start Tag 14
- **Schreiben in**:
  - `apps/web/tests/smoke.spec.ts`
  - `docs/QA_CHECKLIST.md`
- **Abhaengigkeit**: Tag 13
- **Bereitet vor**: reproduzierbare Freigabe
- **Wie schreiben**:
  - Flows: gather, craft, bulk, save, reload, offline reload, sync.
- **DoD**:
  - alle kritischen MVP-Flows gruen.

### Task 14.2 Release-Kandidat + Freeze
- **Zeitpunkt**: Ende Tag 14
- **Schreiben in**:
  - `docs/RELEASE_NOTES_MVP.md`
  - `docs/GO_LIVE_CHECK.md`
- **Abhaengigkeit**: 14.1
- **Bereitet vor**: Deployment
- **DoD**:
  - Scope Freeze, Rollback-Plan, bekannte Risiken dokumentiert.

## 3) Erweiterungspaket (bewusst groesser gedacht)

## A) Tech Debt Guardrails
- Ein zentraler `ACTION_HANDLERS` Layer im Core fuer erweiterbare Commands.
- Save-Migration Tabelle (`v1 -> v2 -> v3`).
- Event-Code-System (`E_GATHER`, `E_CRAFT_SUCCESS`) statt Freitext.

## B) Content Scalability
- Rezeptdaten in JSON/TS-Datafiles mit Validator.
- Tier-basierte Freischaltformel statt hart verdrahteter Schwellen.
- Factory fuer saisonale Event-Rezepte.

## C) UX/Animation Scaling
- Animation Tokens (`--dur-fast`, `--dur-mid`, `--ease-emphasis`).
- Partikel nur auf High-Tier-Crafts.
- Performance-Schalter (`low`, `balanced`, `high`).

## D) App Readiness
- Navigation Contract (Web Router = Mobile Tabs Mapping).
- Screen-State-Container pro Feature statt globaler UI-Coupling.
- Touch/Haptik Events als Adapter.

## 4) Coding-Standards (verbindlich)

1. **Core**
- 100% pure functions fuer Spielregeln.
- Kein Zugriff auf `window`, `document`, `localStorage`.

2. **Store**
- Nur delegation an Reducer + persistence orchestration.
- Keine Spielregeln im Store.

3. **Components**
- Keine Businesslogik ausser disable/formatting.
- Props klar typisiert, keine globalen Imports ohne Bedarf.

4. **Styles**
- Tokens zuerst, Komponenten danach.
- Keine inline hardcoded Farben, ausser prototypische Marker.

## 5) Kritische Integrationspunkte (manuell pruefen)

1. `CRAFT` darf niemals negative Bestandswerte produzieren.
2. Unlocks muessen nach `HYDRATE`, `CRAFT`, `RESET` konsistent sein.
3. Bulk-Craft darf bei Teilverfuegbarkeit nicht inkonsistent rechnen.
4. Save korrupt -> fallback auf initial state ohne UI-Crash.
5. Reduced-motion darf keine Funktion deaktivieren, nur Animation.

## 6) Sofort naechste Implementierungsschritte

1. `canCraft` aus Web-Store in Core-Selector ziehen (Logikzentralisierung).
2. `platform` Adapter in Core einfuehren und Web-Persistenz darauf umstellen.
3. `QA_CHECKLIST.md` und minimale Core-Tests fuer Reducer-Flows erstellen.
