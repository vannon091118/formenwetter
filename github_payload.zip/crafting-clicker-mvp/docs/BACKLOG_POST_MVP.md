# Post-MVP Backlog

## P1
- Idle Produktion mit Gebaeude-System
- Daily Ziele und Reward Truhe
- Economy Balance Tooling

## P2
- Themenwelten und saisonale Rezepte
- Sound-Design und Haptik Adapter
- Erweitertes Statistik-Dashboard

## P3
- Cloud Save
- Leaderboards
- Gilden/Handel
