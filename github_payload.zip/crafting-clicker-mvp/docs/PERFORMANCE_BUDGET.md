# Performance Budget

## Zielgeraete
- Android Midrange mit mobilem Browser.

## Budgets
- Interaktionslatenz pro Klick: < 80ms.
- UI bleibt bedienbar bei 30+ FPS.
- Event-Log capped auf 30 Eintraege.

## Regeln
- Keine teuren Listen-Neuberechnungen pro Render.
- Keine mehrfachen JSON-Serialisierungen pro Tick ausser Save-Pfad.
- Animationen respektieren `prefers-reduced-motion`.
