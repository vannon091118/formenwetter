# Singlefile Source Of Truth

## Ziel
- Eine einzige kanonische Wahrheit in der Datei behalten.
- Persistenz intern und kontrolliert verwalten.
- Keine parallelen Datenquellen.

## Kanonische Wahrheit
1. Kanonischer Dokumenttyp: `PlayerStateDocument`.
2. Kanonischer Runtime-State: `store.state`.
3. Kanonischer Persist-Snapshot: `store.currentDoc`.
4. Kanonischer Builder: `createStateDocument(...)` + `sanitizeState(...)`.

## Interne Wahrheitsregeln
1. Alle Reads/Writes laufen ueber den internen Repository-Pfad.
2. `sanitizeStateDocument(...)` + Migration normalisieren jedes externe Save.
3. `enforceInternalTruthDocument(...)` erzwingt Dokumentform vor Queue/Persist.
4. `integrityCheck(...)` wird bei Save sowie nach Load/Import ausgefuehrt.

## Speicherlogik (intern)
1. Primärer Key: `STORAGE_KEY`.
2. Backup-Key: `STORAGE_KEY-backup`.
3. Managed Keys werden zentral ueber `getManagedStorageKeys(...)` gefuehrt.
4. Queue-Policy: `latest_only_coalescing` (nur letzter Snapshot bleibt pending).

## Erweiterungsregel
1. Neue Felder nur additiv.
2. Migration in `migrateStateDocument(...)` verpflichtend.
3. Kein Feature darf eine zweite Source-of-Truth einführen.
