# Go-Live Check

1. Build erfolgreich fuer `@game/core` und `@game/web`.
2. Gather/Craft/Bulk/Reset funktionieren im Browser.
3. Reload laedt identischen Zustand.
4. Corrupt Save fuehrt nicht zu Crash.
5. Mobile Layout auf kleinem Screen bedienbar.
6. Reduced Motion respektiert Systemeinstellung.
7. Release Notes aktualisiert.
