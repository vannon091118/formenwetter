# QA Checklist MVP

1. Gather auf cloth/leather/wood erhoeht nur die angeklickte Resource.
2. Crafting zieht Input korrekt ab und erhoeht Output korrekt.
3. Bulk Craft x5 arbeitet atomar (entweder korrekt oder nicht).
4. Unlocks aktualisieren nach Craft und nach Laden.
5. Save/Load-Roundtrip bleibt stabil (inkl. Migration v1/v2 -> v3).
6. Corrupt Save erzeugt keinen Crash und faellt auf Backup-Recovery zurueck.
7. Reset setzt alle Counts, Stats, Events und Unlocks korrekt.
8. Buttons disablen, wenn Kosten nicht vorhanden sind.
9. Mobile Layout bei <= 390px Breite bleibt bedienbar.
10. Reduced motion reduziert Animationen, nicht Funktion. (offen)
11. Drag/Long-Press/Tap Konflikte auf Orbs sind stabil. (offen)
12. QA-Aktion im Core-Kontextmenue (`QA`) meldet pass/fail ohne Crash.
