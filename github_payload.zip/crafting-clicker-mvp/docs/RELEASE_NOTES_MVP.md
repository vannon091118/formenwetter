# Release Notes MVP v0.1.0

## Enthalten
- 3 Basisressourcen
- 6 Crafting-Rezepte in 5 Tiers
- Punkte/Level Progression
- Save/Load via localStorage
- Event Feed und Inventar

## Bekannte Grenzen
- Keine Cloud Saves
- Keine Idle-Mechanik im Hintergrund
- Nur ein Screen, keine getrennten Tabs
