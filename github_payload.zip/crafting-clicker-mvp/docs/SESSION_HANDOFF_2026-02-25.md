# Session Handoff - 2026-02-25

## Ziel dieser Session
- Single-File-Architektur stabil halten.
- Source-of-Truth im Code explizit machen.
- RPG-Erweiterung additiv vorbereiten und teilweise implementieren.
- Plan und Dokumentation fuer naechste Session belastbar machen.

## Umgesetzt in dieser Session

1. Daten- und Runtime-Haertung
- Stage-Isolation im Tick-Pfad gehaertet.
- Integritaets-Gates direkt nach Load/Import.
- Unknown-Field-Toleranz im State-Sanitize.
- Persistenz auf Queue-Coalescing (`latest-only`) stabilisiert.
- Interne Source-of-Truth-Verankerung (`INTERNAL_TRUTH`, `enforceInternalTruthDocument`).

2. Modell-Refactor
- Facility-Modell auf Instanzen (`facilityInstanceId`) migriert.
- Schema auf `v3`, danach auf `v4` erweitert.

3. RPG Slice (additiv)
- `state.rpg` eingefuehrt.
- Migration `v3 -> v4` eingefuehrt.
- RPG-Kataloge (`contracts`, `equipment`, `death rules`, `balance`) angelegt.
- RPG-Actions integriert:
  - `RPG_CONTRACT_START`
  - `RPG_CONTRACT_RESOLVE`
  - `RPG_EQUIP_CRAFT`
  - `RPG_EQUIP_ITEM`
  - `RPG_UNEQUIP_ITEM`
  - `RPG_DEATH_RESOLVE`
- RPG-Selectors integriert.
- RPG Dev-Harness integriert: `window.__RPG_DEV__.run(...)` und `window.__RPG_DEV__.smoke()`.

4. Dokumentation
- `AUSFUEHRLICHER_UMSETZUNGSPLAN.md` um Phase 8 erweitert.
- `TODO_RPG_INTEGRATION.md` als operative RPG-TODO angelegt.
- `DATA_CONTRACT.md` auf `v4` aktualisiert.
- `SINGLEFILE_SOURCE_OF_TRUTH.md` angelegt/ergänzt.

5. UI-First Umbau (Orb-Only)
- Klassische Panel-Ansicht deaktiviert; aktive Ansicht ist nur noch ein grosses Orb-Fenster.
- Layout-/Status-Sektionen aus der aktiven Darstellung entfernt.
- Skalierung verdichtet (kleinere Orb-Nodes, kompakteres Radialmenue, kleinere Edge-Chips), damit mehr gleichzeitig sichtbar bleibt.
- Core-Kontextmenue auf verschachtelte Pfade umgestellt:
  - `build`
  - `flow`
  - `system`
  - `io`
  - `rpg`

## Offene Hauptpunkte fuer naechste Session

1. Phase 8k - RPG UI/UX v1
- Text-only Render-Hooks fuer Contracts, Gear, Durability, Death-Info.
- RPG-Kontextmenu von Placeholder-Aktionen auf finale Flows umstellen.

2. Phase 8l - RPG Quality Gates
- RPG-spezifische Tests in `runQualityGates()` aufnehmen:
  - Contract start/resolve
  - Equip/Unequip Referenzintegritaet
  - Death -> Gear-Loss Referenzintegritaet
  - Save/Load vor/nach v4-Migration

3. Phase 8j Rest
- Quarantaene-Regeln fuer unbekannte RPG-Template-Referenzen statt stilles Verwerfen.

## Startpunkt (empfohlen)

1. Datei oeffnen:
- `crafting_clicker_singlefile.html`

2. Dann nacheinander:
- RPG-Render-Funktionen hinzufuegen.
- Kontextmenu um finale RPG-Aktionen erweitern.
- Quality-Gate-Testfaelle fuer RPG aufnehmen.

## Schnellpruefung

Syntaxcheck:
```sh
tmp_js=$(mktemp --suffix=.js) && awk 'BEGIN{in_script=0} /<script>/{in_script=1;next} /<\\/script>/{in_script=0} in_script{print}' crafting_clicker_singlefile.html > "$tmp_js" && node --check "$tmp_js" && rm -f "$tmp_js"
```

RPG-Relevanz im Code finden:
```sh
rg -n "SCHEMA_VERSION = 4|state.rpg|RPG_|E_RPG_|migrateV3ToV4|runRpgDevDispatch|__RPG_DEV__" crafting_clicker_singlefile.html
```
