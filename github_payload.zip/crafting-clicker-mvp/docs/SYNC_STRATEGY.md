# Sync Strategy v1

## Modell
- Local-first: jede Aktion wird sofort lokal angewendet.
- Queue speichert `UPSERT_PLAYER_STATE` Operationen.
- Beim Flush wird der letzte Snapshot persistiert.
- Persistenz ist `changed-state only` (keine Schreiboperation bei gleicher Signatur).

## Konflikte
- Last-write-wins auf Basis `updatedAt`.
- Es gibt keinen externen Merge im MVP, der letzte gueltige lokale Snapshot gewinnt.

## Fehlerpfad
- Primarer Save liegt unter `STORAGE_KEY`, Backup unter `STORAGE_KEY-backup`.
- Bei korruptem Hauptsave wird automatisch Backup geladen.
- Recovery wird als `state.recoveryReport` + `E_RECOVERY` Event protokolliert.
- Bei Save-Fehlern bleibt Queue erhalten und kann spaeter erneut geflusht werden.
