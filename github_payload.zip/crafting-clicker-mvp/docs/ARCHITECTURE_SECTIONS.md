# Architecture Sections (Single-File)

Ziel: Eine feste, nachvollziehbare Sektionsordnung in `crafting_clicker_singlefile.html`, damit Erweiterungen ohne Architekturdrift erfolgen.

## Verbindliche Reihenfolge

1. `CONFIG`
2. `CATALOGS`
3. `STATE FACTORY + SANITIZE + MIGRATION`
4. `CORE RULES (pure)`
5. `SIMULATION PIPELINE`
6. `STORE + SYNC QUEUE`
7. `UI STATE`
8. `RENDER`
9. `INTERACTIONS`
10. `BOOTSTRAP + RECOVERY`

## Ownership pro Sektion

1. `CONFIG`
- Konstante IDs, Limits, Feature-Flags, Event-Codes.
- Keine Laufzeitlogik.

2. `CATALOGS`
- Rezeptkataloge, Metadaten, Kosten-Tabellen.
- Keine State-Mutation.

3. `STATE FACTORY + SANITIZE + MIGRATION`
- `createInitialState`, `sanitizeState`, `sanitizeStateDocument`, `migrateStateDocument`.
- Einzige Stelle fuer Schemaentwicklung.

4. `CORE RULES (pure)`
- Pure Berechnungen/Validatoren (`hasIngredients`, `isRecipeUnlocked`, usw.).
- Kein DOM, kein Storage.

5. `SIMULATION PIPELINE`
- Tick-Stages und Fehlerisolation (`runSimulationStage`).
- Deterministische Reihenfolge gemaess `SIMULATION_STAGE_ORDER`.

6. `STORE + SYNC QUEUE`
- `dispatch`, `reduce`, Queue, Persistenz, Recovery-Fallback.
- Keine DOM-Manipulation.

7. `UI STATE`
- Menuezustand, Gestenstatus, lokale UI-Flags.
- Kein Datenvertragsbruch.

8. `RENDER`
- Read-only Darstellung aus Store-State.
- Darf Business-State nicht mutieren.

9. `INTERACTIONS`
- Event-Handler, Kontextmenu-Aktionen, User-Intents.
- State-Aenderungen nur via `dispatch` oder klarer, begruendeter Store-Operation.

10. `BOOTSTRAP + RECOVERY`
- Startreihenfolge, initiales `load`, Timer, globale Error/Recovery-Anbindung.

## Guardrails

1. Kein Feature ohne Schema-Impact-Entscheidung:
- `none` oder `field-add` mit Migration.

2. Keine parallele Source of Truth:
- Kanonische Datenbasis ist `PlayerStateDocument`.

3. Action-Sicherheit:
- Nur erlaubte Actions (`ACTION_WHITELIST`), ungueltige Inputs sind No-Op + Event.

4. Recovery statt Hard-Crash:
- Fehlerpfade erzeugen `recoveryReport` und Event-Code.

## Erweiterungs-Check (kurz)

1. Welche Sektion ist Owner?
2. Braucht es Schema-Update/Migration?
3. Welche Action + Payload-Validierung wird eingefuehrt?
4. Welche Render-Auswirkung ist sichtbar?
5. Welcher Recovery-Pfad gilt bei Fehlern?
