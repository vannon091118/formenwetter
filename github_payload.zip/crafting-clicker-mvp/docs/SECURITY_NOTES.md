# Security Notes

## Scope
- Client-seitiges Spiel ohne serverseitige Validierung.

## Hardening
- Save-Daten werden durch `sanitizeState` und `sanitizeStateDocument` validiert.
- Negative und inkonsistente Werte werden abgefangen.
- Unbekannte Felder werden ignoriert.

## Restrisiko
- Reine Client-Apps koennen lokal manipuliert werden.
- Bei spaeterem Backend-Mode muss serverseitige Validierung den finalen Zustand prufen.
