# Data Contract v4

## PlayerStateDocument

```json
{
  "schemaVersion": 4,
  "playerId": "local-player",
  "updatedAt": "2026-02-25T12:00:00.000Z",
  "state": {
    "version": 1,
    "tick": 0,
    "level": 1,
    "points": 0,
    "automation": {
      "workers": { "cloth": 0, "leather": 0, "wood": 0 },
      "autoCraft": { "bag_t1": false },
      "enabled": true
    },
    "rpg": {
      "gold": 30,
      "activeContracts": [],
      "contractHistory": [],
      "equipmentInstances": {},
      "equipmentSlots": { "weapon": null, "armor": null, "trinket": null },
      "deathStats": { "totalDeaths": 0, "lastDeathAtTick": null, "lastCause": null },
      "audit": [],
      "rng": { "seed": 1337, "nonce": 0 },
      "featureFlags": {
        "rpgEnabled": true,
        "rpgContracts": true,
        "rpgEquipment": true,
        "rpgDurability": true,
        "rpgDeathLoss": true
      },
      "nextEquipmentSeq": 1
    },
    "ui": {
      "orbLayout": {},
      "selectedOrbId": null,
      "facilityInstances": [
        { "id": "facility:bag_t1:1", "recipeId": "bag_t1", "createdAt": "2026-02-25T12:00:00.000Z" }
      ],
      "nextFacilitySeq": 2,
      "viewMode": "none"
    },
    "inventory": {},
    "unlockedRecipes": [],
    "crafted": {},
    "stats": {
      "totalClicks": 0,
      "totalCrafts": 0,
      "totalPointsEarned": 0
    },
    "recoveryReport": null,
    "lastEvents": []
  }
}
```

## Migrationen
- `v1 -> v2`: `recoveryReport` hinzugefuegt.
- `v2 -> v3`: `ui.spawnedFacilityIds` nach `ui.facilityInstances` migriert, `ui.nextFacilitySeq` eingefuehrt.
- `v3 -> v4`: additiver `state.rpg`-Slice mit Defaults eingefuehrt.

## Invarianten
- `schemaVersion` ist aktuell `4`, `state.version` bleibt `1`.
- Numerische Felder sind nie negativ.
- `level` wird aus `points` abgeleitet.
- `ui.facilityInstances[*].id` folgt dem Muster `facility:<recipeId>:<seq>`.
- `state.rpg.gold` ist nie negativ.
- `state.rpg.equipmentSlots[*]` referenzieren nur existierende Instanzen in `state.rpg.equipmentInstances`.
- `state.rpg.activeContracts[*].contractId` referenzieren gueltige IDs aus dem RPG-Contract-Katalog.
- Nur Daten aus `crafting_clicker_singlefile.html` gelten als kanonisch.
