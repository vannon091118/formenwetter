# Single-Daten-Basis (Web)

## Ziel
- Genau eine kanonische Spieler-Datenstruktur (`player_state`) fuer Web und spaetere App.
- Lokaler Cache ist nur Spiegel, nicht zweite Logikquelle.

## Kanonisches Dokument
- `version`
- `playerId`
- `updatedAt`
- `state` (entspricht `GameState` aus Core)

## Regeln
1. Spielregeln nur in `packages/core`.
2. Persistenz ueber Repository-Interface.
3. Sync immer auf Basis von `updatedAt` + Version.
4. Migrationen zentral (v1 -> v2 ...), nie ad hoc.
5. UI liest nur View-State; keine Shadow-Datenmodelle.

## Mobile-Funktionalitaet
- local-first schreiben.
- Queue-basierte Sync bei Verbindungswiederkehr.
- Datenmenge klein halten, um langsame Geraete zu schonen.
