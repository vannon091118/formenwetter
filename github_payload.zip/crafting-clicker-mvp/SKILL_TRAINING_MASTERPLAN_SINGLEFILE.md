# Skill Training Masterplan: Single-File + Single-Data-Base

## Zielbild
Ein belastbares Skill-Ökosystem aufbauen, das alle Kernanforderungen abdeckt:
- Single-File-Entwicklung mit klarer Modulstruktur
- State-Management, State-Chains, Migrationen und Recovery
- grafische/visuelle Darstellung ohne Asset-Zwang
- robuste Fehlerbehandlung und Erweiterbarkeit
- dokumentierte ID-Logik und kontrolliertes Whitelisting
- reproduzierbare Problemlösung über Repo-Ressourcen und Alternativpfade

---

## 1) Skill-Landkarte (was trainiert werden muss)

### 1.1 Core-Engineering Skills
1. `singlefile-architecture`
- In-File-Sektionsschema, Entkopplung von Logik/Render/Interaction
- Regeln für additive Erweiterungen

2. `single-database-contract`
- PlayerStateDocument, schemaVersion, sanitize/migrate/integrity
- Roundtrip-Stabilität (`save -> load -> compare`)

3. `state-chain-engineering`
- deterministische Tick-Pipeline
- Stage-Isolation bei Fehlern
- Chain-Prioritäten und Konfliktauflösung

4. `id-system-governance`
- ID-Namensraum, Referenzregeln, Parent-Child-IDs
- stabile IDs für Persistenz und Migration

5. `whitelist-policy-control`
- erlaubte Action-Typen, erlaubte State-Felder, erlaubte UI-Effekte
- Runtime-Guards gegen nicht freigegebene Mutationen

### 1.2 UX/Visual Skills
6. `symbolic-ui-orb-systems`
- Orbs, symbolische Kanten, Statusfarben, Bedeutungskodierung
- visuelle Lesbarkeit ohne komplexe Art-Assets

7. `context-menu-interaction`
- radiale Menüs, Touch-Handling, fallback-friendly Interaktion
- max. Action-Tiefe und Action-Paging

8. `pipeline-visual-diagnostics`
- Fluss-Status, Engpassdarstellung, Chain-Debug-Overlays

### 1.3 Reliability & Operations Skills
9. `singlefile-recovery-ops`
- recoveryReport, rollbackFlag, killSwitch
- partielle Wiederherstellung statt Full-Reset

10. `repo-resource-resolution`
- wo welche Referenz liegt, wie Alternativen gewählt werden
- Entscheidungsbaum für „Primary path“ vs „Fallback path“

---

## 2) Skill-Spezifikation (Template für jede Skill-Implementierung)
Jede Skill muss enthalten:
1. **Triggerbeschreibung** (wann einsetzen)
2. **Nicht-Ziele** (wann nicht einsetzen)
3. **Pflicht-Inputs**
4. **Pflicht-Outputs**
5. **Guards/Checks**
6. **Fehlerpfade + Recovery**
7. **Alternative Wege**
8. **Verknüpfte Repo-Ressourcen**
9. **Abnahme-Kriterien**

Empfohlene Struktur pro Skill-Verzeichnis:
- `SKILL.md`
- `references/*.md`
- `scripts/*.sh|*.py` (nur für deterministische Checks/Generatoren)

---

## 3) Single-File Referenzarchitektur (verpflichtend)

### 3.1 Feste In-File-Blöcke
1. `CONFIG`
2. `CATALOGS`
3. `STATE_FACTORY_SANITIZE_MIGRATE`
4. `RULES_PURE`
5. `SIMULATION_PIPELINE`
6. `STORE_SYNC`
7. `UI_STATE`
8. `RENDER`
9. `INTERACTION`
10. `BOOTSTRAP_RECOVERY`

### 3.2 Verbotene Vermischungen
- kein Business-Write im Render-Block
- kein Persistenzzugriff im reinen Rule-Block
- keine UI-spezifischen Entscheidungen im Migration-Block

---

## 4) State-Expertise Curriculum (Kern deiner Anforderung)

### 4.1 Pflichtwissen
1. **State-Typen**
- domain state
- derived state
- ui state
- ephemeral runtime state

2. **State-Chains**
- Chain = geordnete Stage-Liste mit klarer Eingabe/Ausgabe
- jede Stage darf nur ihren Scope mutieren

3. **State-Migrationen**
- nur additive Felder
- harte Konvertierungen mit Migrationspfad
- alle Migrationen idempotent

4. **State-Integrity**
- invariants vor und nach Tick
- invariants vor Persist

### 4.2 Chain-Policy
- Stages haben feste IDs (`stage_contracts`, `stage_costs`, ...)
- Stage-Fehler schreibt Event + überspringt nur betroffene Stage
- keine impliziten Seiteneffekte über globale Variablen

---

## 5) ID-Logik (essenziell, dokumentiert)

### 5.1 ID-Format
- `resource:<slug>`
- `recipe:<slug>`
- `facility:<instance-id>`
- `edge:<from>:<to>:<item>`
- `event:<ts>:<seq>`

### 5.2 Regeln
1. IDs sind unveränderlich nach Persistenz
2. keine Re-Use alter IDs für neue Entitäten
3. referenzielle Integrität bei delete/sell
4. unknown IDs -> warn + quarantine statt crash

### 5.3 Pflichtdokumente
- `ID_NAMESPACE.md`
- `ID_LIFECYCLE.md`
- `ID_MIGRATION_RULES.md`

---

## 6) Whitelisting-Plan (anpassbar, aber kontrolliert)

### 6.1 Action-Whitelist
- erlaubte Action-Typen explizit im Registry-Objekt
- unbekannte Actions => reject + event

### 6.2 Mutation-Whitelist
- pro Action definieren: erlaubte State-Pfade
- path-level guard verhindert Seiteneffekt-Ausreißer

### 6.3 Render-Whitelist
- nur zugelassene UI-Operations (draw/update/show/hide)
- kein direkter Domain-State-Write aus UI-Handlers

### 6.4 Konfigurierbarkeit
- `WHITELIST_PROFILE = strict|balanced|debug`
- debug nur lokal, nie als default release

---

## 7) Grafik-/Visual-Pfade (inkl. Alternativen)

### 7.1 Primary Path (asset-light)
- symbolische Icons + Kanten + Farbcodes
- keine externen Grafikpakete nötig

### 7.2 Alternative Path A (SVG-first)
- visuelle Qualität über SVG-Definitions
- theming via CSS-Variablen

### 7.3 Alternative Path B (Icon-Pack optional)
- austauschbares Icon-Mapping
- fallback auf emoji/symbol wenn Asset fehlt

### 7.4 Fallback-Regel
- jede visuelle Komponente muss Textfallback haben

---

## 8) Repo-Ressourcen-Strategie (jederzeit nutzbar)

### 8.1 Resource Registry
Pflege ein zentrales Register mit:
- Dateipfad
- Zweck
- Owner-Skill
- Fallback-Ressource

### 8.2 Zugriffsmuster
1. Primärquelle lesen
2. Falls unklar: Referenzdatei mit Schema öffnen
3. Falls fehlt: Fallback-Skript/Template nutzen
4. Ergebnis gegen Invariants prüfen

### 8.3 Konfliktlösung
- bei widersprüchlichen Quellen: Skill-Owner-Regel entscheidet
- Entscheidung immer als Event dokumentieren

---

## 9) Fehler- und Recovery-System

### 9.1 Error Classes
- validation_error
- chain_stage_error
- migration_error
- render_error
- persistence_error

### 9.2 Recovery-Strategien
- partial rollback (nur betroffene Stage)
- safe defaults für fehlende Felder
- quarantine für ungültige IDs
- notfall `rebuildDerivedState()`

### 9.3 Pflicht-Outputs
- `recoveryReport`
- `eventCode`
- `nextActionHint`

---

## 10) Evaluationskriterien pro Skill

1. Trigger-Erkennung korrekt
2. Kein ungewollter State-Side-Effect
3. Recovery bei absichtlich injizierten Fehlern
4. Save-Load-Roundtrip stabil
5. Erweiterung ohne Bruch bestehender IDs
6. Whitelist-Verletzung wird abgefangen

---

## 11) Priorisierte Umsetzungsreihenfolge (ohne Zeitabhängigkeit)

1. `id-system-governance`
2. `single-database-contract`
3. `state-chain-engineering`
4. `whitelist-policy-control`
5. `singlefile-recovery-ops`
6. `symbolic-ui-orb-systems`
7. `context-menu-interaction`
8. `pipeline-visual-diagnostics`
9. `repo-resource-resolution`

---

## 12) Minimaler Startsatz (sofort implementierbar)

1. Action-Registry + Action-Whitelist einführen
2. `facilityInstanceId` statt reiner recipe-ID-Instanzen
3. `integrityCheck(state)` vor Persist verpflichtend
4. `migrateState(v1->v2)` mit dokumentierter ID-Konvertierung
5. `recoveryReport` und `eventCode`-Pflicht bei Fehlerpfaden

---

## 13) Governance-Regeln für spontane Ideen

1. Neue Idee nur mit IdeaCard
2. Jede Idee braucht eine Exit-Strategie (`rollbackFlag`)
3. Keine direkte Aufnahme ohne Invariant-Check
4. Keine UI-Idee ohne State-/Persistenz-Auswirkungsklärung
5. Keine neue ID-Klasse ohne Namespace-Dokumentation

