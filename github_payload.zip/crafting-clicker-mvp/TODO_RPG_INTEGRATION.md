# TODO RPG Integration (Single-File, Additiv)

## Phase 8a - RPG Dev Sandbox
- [x] `runRpgDevDispatch(actions)` mit Mutation/Event-Logging hinzugefuegt
- [x] `window.__RPG_DEV__` (`run`, `smoke`) fuer isolierte Dev-Runs
- [ ] Feste Seed-Szenarien als reproduzierbare Testfaelle ausbauen

## Phase 8b - RPG Mini-Vertrag
- [x] `state.rpg` als exklusiver Scope eingefuehrt
- [x] Action-Namespace `RPG_*` eingefuehrt
- [x] Event-Namespace `E_RPG_*` eingefuehrt
- [x] Invarianten technisch verankert (Gold, Slot-Referenzen, Contract-Referenzen)

## Phase 8c - Datenvertrag + Migration
- [x] `schemaVersion` auf `4` angehoben
- [x] Migration `v3 -> v4` fuer `state.rpg` hinzugefuegt
- [x] `sanitizeRpgState()` integriert
- [x] `integrityCheck()` um RPG-Pruefungen erweitert

## Phase 8d - RPG Kataloge (data-first)
- [x] `RPG_CONTRACT_CATALOG`
- [x] `RPG_EQUIPMENT_TEMPLATES`
- [x] `RPG_DEATH_RULES`
- [x] `RPG_BALANCE_CONSTANTS`
- [x] Indexes (`RPG_CONTRACT_INDEX`, `RPG_EQUIPMENT_INDEX`)

## Phase 8e - Contracts v1
- [x] `RPG_CONTRACT_START`
- [x] `RPG_CONTRACT_RESOLVE`
- [x] Deterministische Resolve-Logik (seed/tick-basiert)
- [x] Event-Logging fuer Start/Success/Fail
- [x] Selectoren (`selectRpgGold`, `selectActiveContracts`, `selectAvailableContracts`, `selectContractCanStart`)

## Phase 8f - Equipment Instanzen v1
- [x] Instanzmodell (`equipmentInstances`, `nextEquipmentSeq`)
- [x] `RPG_EQUIP_CRAFT`
- [x] `RPG_EQUIP_ITEM`
- [x] `RPG_UNEQUIP_ITEM`
- [x] Selectoren (`selectEquippedItems`, `selectGearScore`, `selectCraftableEquipment`)

## Phase 8g - Durability on Use
- [x] Durability-Drain bei Contract-Resolve integriert
- [x] Events `E_RPG_DURA_LOSS` und `E_RPG_ITEM_BROKEN`
- [ ] Feingranulare Drain-Profile pro Contract-Tier erweitern

## Phase 8h - Death Loss Gear
- [x] `RPG_DEATH_RESOLVE` implementiert
- [x] Gear-Loss auf geslottete Items umgesetzt
- [x] Events `E_RPG_DEATH` und `E_RPG_GEAR_LOST`

## Phase 8i - Policy/Whitelist
- [x] RPG-Actions in `ACTION_WHITELIST`
- [x] RPG-Mutationspfade in `MUTATION_PATH_WHITELIST`
- [x] RPG-Events in `EVENT_CODES`
- [ ] Strict-Policy-Regressiontests fuer alle RPG-Actions

## Phase 8j - Sanitization/Integrity Hardening
- [x] `sanitizeRpgState()` produktiv verdrahtet
- [x] RPG-Integritaetspruefungen in `integrityCheck()`
- [ ] Quarantaene fuer unbekannte RPG-Templates statt drop

## Phase 8k - UI/UX v1 (text-only)
- [ ] RPG-Panel Render-Hooks
- [ ] Kontextmenue-Aktionen fuer RPG-Flow
- [ ] Mobile/Reduced-Motion-Pass

## Phase 8l - Quality Gates RPG
- [ ] Eigene RPG-Gates in `runQualityGates()` erweitern
- [ ] Save/Load-Migration-Runs mit RPG-State automatisieren
- [ ] Determinismus-Regressionen (gleiches Seed => gleiches Ergebnis)
