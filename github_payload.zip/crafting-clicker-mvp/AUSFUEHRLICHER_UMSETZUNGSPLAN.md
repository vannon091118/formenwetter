# Ausfuehrlicher Umsetzungsplan

Ziel: Die TODO-Liste systematisch in eine stabile, erweiterbare Single-File-Architektur ueberfuehren, ohne bestehende Spielstaende oder Laufzeitstabilitaet zu riskieren.

## Phase 0 - Arbeitsrahmen und Baseline (Tag 1)

1. Ist-Zustand einfrieren
- Aktuellen Stand der Datei `crafting_clicker_singlefile.html` sichern.
- Bestehende Save-Daten (falls vorhanden) als Testfaelle sichern.

2. Baseline-Checks definieren
- Manueller Smoke-Test: Start, Ressourcen anzeigen, Crafting, Spawn/Sell, Save/Load.
- Ziel: Vor jedem Refactor gleiche Kernfunktion weiterhin lauffaehig.

3. Deliverables
- Baseline-Checklist dokumentiert.
- Referenz-Save-Datei fuer Migrationstests vorhanden.

Definition of Done:
- Vorher/Nachher-Smoke-Test ist reproduzierbar.

## Phase 1 - Architektur-Kontrakt und Dateistruktur (Tag 1-2)

1. Single-Source-of-Truth festziehen
- Runtime-Quelle bleibt `crafting_clicker_singlefile.html`.
- Datenmodell bleibt `PlayerStateDocument`.

2. Feste Sektionsreihenfolge herstellen
- `CONFIG`
- `CATALOGS`
- `STATE FACTORY + SANITIZE + MIGRATION`
- `CORE RULES (pure)`
- `SIMULATION PIPELINE`
- `STORE + SYNC QUEUE`
- `UI STATE`
- `RENDER`
- `INTERACTIONS`
- `BOOTSTRAP + RECOVERY`

3. Entwicklungsregel verankern
- Neue Idee muss enthalten: `Action`, `Selector`, `Render-Hook`.
- Schema-Impact je Feature verpflichtend (`none` oder `field-add`).

Definition of Done:
- Datei folgt der Zielreihenfolge.
- Jede neue Aenderung kann klar einer Sektion zugeordnet werden.

## Phase 2 - Datenvertrag und Invarianten (Tag 2-3)

1. `sanitizeState` erweitern
- Keine negativen Ressourcen.
- `level` immer aus `points` ableiten.
- `spawnedFacilityIds` nur mit gueltigen Rezepten.
- Auto-Craft nur fuer existierende Facility-Instanzen.
- Orb-Layout unbekannte Nodes nicht zerstoeren.

2. Datenintegritaet absichern
- `schemaVersion` verpflichtend validieren.
- Unbekannte Felder tolerieren (keine aggressive Bereinigung).
- `integrityCheck()` vor Persist aufrufen.

3. Save-Load-Roundtrip absichern
- `save -> load -> save` ohne Drift im State.

Definition of Done:
- Alle Invarianten in `sanitizeState` oder `integrityCheck()` technisch erzwungen.
- Save/Load-Roundtrip mit Referenzdaten stabil.

## Phase 3 - Migration und Persistenzstrategie (Tag 3-4)

1. Sequenzielle Migrationen einfuehren
- Klare Pipeline `v1 -> v2 -> v3 ...`.
- Jede Migration rein additiv (keine stillen Feldentfernungen).

2. Persistenz auf "changed-state only" umstellen
- Nur speichern, wenn sich relevanter State geaendert hat.
- Integritaetspruefung vor jedem Persist.

3. Recovery bei korrupten Saves
- `sanitize + Teilwiederherstellung`.
- Fehlerprotokoll fuer Nutzerhinweis/Debug (`recoveryReport`).

Definition of Done:
- Alte Saves koennen kontrolliert auf aktuelle Version migriert werden.
- Keine unnoetigen Persist-Schreibvorgaenge mehr.

## Phase 4 - Simulation stabilisieren (Tag 4-5)

1. Tick-Order festschreiben
- Reihenfolge dokumentieren und zentral implementieren.

2. Tick-Ausfuehrung begrenzen
- Auto-Tick nur bei aktiven Produzenten/Auto-Craft.

3. Konflikt- und Fehlerisolation
- Deterministische Konfliktregeln definieren.
- Stage-Fehler isolieren (kein Gesamtabbruch der Simulation).

4. Event-Volumen kontrollieren
- Log-Cap beibehalten/verstaerken.

Definition of Done:
- Simulation verhaelt sich bei gleichen Inputs reproduzierbar.
- Einzelne Stage-Fehler legen das Spiel nicht lahm.

## Phase 5 - UI/UX-Haertung (Tag 5-6)

1. Kontextmenue als einziges Aktionsmodell
- Menues konsistent nur ueber Kontextinteraktion.

2. Bedienbarkeit sichern
- Ressourcen-HUD klein und direkt antippbar.
- Radialmenue mit Paging/Zweite Ebene fuer >10 Aktionen.

3. Resilienz in Darstellung
- Edge-Symbolik mit lesbaren Fallbacks.
- Reduced-Motion ohne Funktionsverlust.

4. Fehlerbehandlung im UI
- Fehler in Kontextaktionen: Toast + Recovery-Pfad.

Definition of Done:
- Alle Kernaktionen sind ueber Kontextmenue erreichbar.
- UI bleibt auf kleinen Displays bedienbar.

## Phase 6 - Priorisierte Refactor-Bloecke (Tag 6-8)

1. Facility-Modell auf `facilityInstanceId` umstellen.
2. Auto-Craft an aktive Instanzen binden.
3. Orb-Layout-Sanitize auf dynamische Node-Keys umbauen.
4. Persist-Strategie final haerten (changed-state only).
5. Radialmenue-Paging final implementieren.
6. `integrityCheck()` + `recoveryReport` in System-Kontextmenue integrieren.

Definition of Done:
- Alle 6 priorisierten Bloecke implementiert und im Smoke-Test bestanden.

## Phase 7 - Quality Gates vor jeder Erweiterung (laufend)

Pflichttests:
1. `sanitizeState` gegen kaputte Inputs.
2. Spawn/Sell/Auto-Craft-Konsistenz.
3. Save-Load vor/nach Migration.
4. Drag/Long-Press/Tap-Konflikte.
5. Auto-Tick-Stresstest ohne UI-Lag.

Abbruchkriterien:
- Bei Regression in Save/Load oder Tick-Determinismus keine Feature-Freigabe.

## Phase 8 - RPG Slice Integration (additiv, single-file)

8a. RPG Dev Sandbox
- `runRpgDevDispatch(actions)` mit Mutation/Event-Logging.
- Deterministische Smoke-Seeds fuer Contract/Equipment/Death.

8b. RPG Mini-Vertrag
- RPG-Daten nur unter `state.rpg`.
- RPG-Actions unter `RPG_*`, Events unter `E_RPG_*`.
- Invarianten: `gold >= 0`, gueltige Slot- und Contract-Referenzen.

8c. Datenvertrag + Migration
- Schema additiv auf `v4`.
- Migration `v3 -> v4` fuegt `state.rpg` defaults hinzu.
- `sanitizeRpgState()` + RPG-Pruefungen in `integrityCheck()`.

8d. Data-first Kataloge
- `RPG_CONTRACT_CATALOG`, `RPG_EQUIPMENT_TEMPLATES`, `RPG_DEATH_RULES`, `RPG_BALANCE_CONSTANTS`.
- Stabile IDs + Indexe, keine Renderlogik in Katalogen.

8e. RPG Core Loop v1
- `RPG_CONTRACT_START`, `RPG_CONTRACT_RESOLVE`.
- Deterministische Resolve-Logik, Event- und Audit-Kette.

8f. Equipment Instanzen v1
- `RPG_EQUIP_CRAFT`, `RPG_EQUIP_ITEM`, `RPG_UNEQUIP_ITEM`.
- Instanzbasiertes Gear-Modell mit Slots + Durability.

8g. Durability on Use
- Eventbasierter Verschleiss bei Contract-Resolve.
- Events `E_RPG_DURA_LOSS`, `E_RPG_ITEM_BROKEN`.

8h. Death + Gear Loss
- `RPG_DEATH_RESOLVE` fuer reproduzierbare Verlustregeln.
- Events `E_RPG_DEATH`, `E_RPG_GEAR_LOST`.

8i. Policy/Whitelist Nachzug
- Alle RPG-Actions in `ACTION_WHITELIST`.
- Mutationspfade in `MUTATION_PATH_WHITELIST`.
- Payload-Validierung und Blockierung unerlaubter Aktionen.

8j. Sanitization/Integrity Hardening
- RPG-spezifische Recovery-Pfade bei korrupten Saves.
- Quarantaene-Regeln fuer unbekannte Template-Referenzen.

8k. UI/UX v1 (text-only)
- RPG-Render-Hooks + Kontextmenu-Flows.
- Mobile-Bedienbarkeit + Reduced-Motion-Kompatibilitaet.

8l. RPG Quality Gates
- Contract/Equipment/Death/Determinismus-Regressionssuite.
- Save/Load-Roundtrip vor/nach Migration.

## Arbeitsmodus fuer neue Features (ab sofort)

Pro Idee eine `IdeaCard` mit:
1. `id`
2. `intent`
3. `data fields`
4. `actions`
5. `render delta`
6. `risk`
7. `rollbackFlag`/`killSwitch`
8. Event-Code (mindestens einer)

Freigabe-Regel:
- Erst Datenvertrag und Migration klaeren, dann UI.

## Empfohlene Reihenfolge (Kurzfassung)

1. Architektur + Sektionsstruktur
2. Invarianten + Sanitize + Integrity
3. Migration + Persist
4. Simulation
5. UI/UX + Kontextmenue-Paging
6. Priorisierte Refactor-Bloecke
7. Laufende Quality Gates
8. RPG Slice Integration (8a bis 8l)

## Aufwandsschaetzung

- Minimal stabil: 5-6 Arbeitstage.
- Voll mit allen priorisierten Refactors: 8-10 Arbeitstage.

## Risiken und Gegenmassnahmen

1. Risiko: Save-Inkompatibilitaet.
- Gegenmassnahme: Sequenzmigration + Referenz-Saves + Roundtrip-Test.

2. Risiko: Tick-Nebenwirkungen durch Refactor.
- Gegenmassnahme: feste Tick-Order + Stage-Isolation + Stresstests.

3. Risiko: UI-Komplexitaet durch zu viele Aktionen.
- Gegenmassnahme: Kontextmenue-Paging + klare Aktionsgruppen.

4. Risiko: RPG-Erweiterung bricht bestehende Kernlogik.
- Gegenmassnahme: Additiver `state.rpg`-Slice, strikt namespacete Actions/Events, Quality Gates vor Freigabe.

## Session-Stand (2026-02-25)

Bereits umgesetzt:
1. Source-of-Truth-Haertung (`INTERNAL_TRUTH`, `enforceInternalTruthDocument`).
2. Persistenz-Haertung (Backup-Recovery, changed-state-only, Queue-Coalescing).
3. Pipeline-Haertung (Stage-Isolation, deterministische Tick-Order).
4. Facility-Instanzmodell mit Migration.
5. RPG Grundintegration:
- Schema `v4` + Migration `v3 -> v4`.
- `state.rpg` + `sanitizeRpgState` + RPG-Integritaetspruefungen.
- RPG-Kataloge und Indizes.
- RPG-Actions fuer Contracts/Equipment/Death.
- RPG-Selectoren und Dev-Harness (`window.__RPG_DEV__`).

Offener Startpunkt fuer naechste Session:
1. Phase `8k` (RPG Render/UI text-only).
2. Phase `8l` (RPG Quality Gates vollstaendig).
3. Phase `8j` Quarantaene fuer unbekannte RPG-Templates.
