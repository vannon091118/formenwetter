# TODO Entwicklungsplan (Single-File + Single-Data-Base)

## Architektur-Kontrakt
- [ ] Eine Laufzeitquelle behalten: `crafting_clicker_singlefile.html`
- [ ] Eine kanonische Datenbasis behalten: `PlayerStateDocument`
- [ ] Jede neue Idee muss enthalten: `Action`, `Selector`, `Render-Hook`
- [ ] Kein Feature ohne Schema-Impact-Deklaration (`none` oder `field-add`)
- [ ] UI-State und Business-Logik strikt getrennt halten

## In-File-Sektionsstruktur
- [ ] Reihenfolge in der HTML fixieren:
- [ ] `CONFIG`
- [ ] `CATALOGS`
- [ ] `STATE FACTORY + SANITIZE + MIGRATION`
- [ ] `CORE RULES (pure)`
- [ ] `SIMULATION PIPELINE`
- [ ] `STORE + SYNC QUEUE`
- [ ] `UI STATE`
- [ ] `RENDER`
- [ ] `INTERACTIONS`
- [ ] `BOOTSTRAP + RECOVERY`

## Invarianten
- [x] Keine negativen Ressourcen zulassen
- [x] `level` immer aus `points` ableiten
- [x] `facilityInstances` nur mit gültigen Rezepten
- [x] Auto-Craft nur für vorhandene Facility-Instanzen
- [x] Orb-Layout darf unbekannte Nodes nicht zerstören
- [x] Save-Load-Roundtrip muss stabil bleiben

## Erweiterungsprotokoll (spontane Ideen)
- [ ] Jede neue Idee als `IdeaCard` erfassen:
- [ ] `id`, `intent`, `data fields`, `actions`, `render delta`, `risk`
- [x] Nur additive Migrationen erlauben
- [ ] Neue Features zuerst im Kontextmenü integrieren
- [ ] Für jede Idee `rollbackFlag`/`killSwitch` vorsehen
- [ ] Für jede Idee mindestens ein Event-Code vergeben

## Fehlerstabilität Runtime
- [x] Alle Actions mit Payload-Validierung absichern
- [x] Ungültige Action -> No-Op statt Crash
- [ ] Render-Funktionen dürfen State nicht mutieren
- [x] Fehler in Kontextaktionen -> Toast + Recovery
- [x] Corrupt Save -> sanitize + Teilwiederherstellung

## Fehlerstabilität Daten
- [x] `schemaVersion` verpflichtend prüfen
- [x] Sequenzielle Migrationen (`v1 -> v2 -> v3`) einführen
- [ ] Unbekannte Felder tolerieren (nicht löschen)
- [x] `integrityCheck()` vor Persist ergänzen
- [x] Nur bei echten State-Änderungen persistieren

## Simulation stabilisieren
- [x] Tick-Reihenfolge fest dokumentieren
- [x] Auto-Tick nur bei aktiven Producern/Auto-Craft laufen lassen
- [x] Konfliktregeln deterministisch definieren
- [x] Stage-Fehler isolieren statt Gesamtabbruch
- [x] Event-Volumen drosseln (Log-Cap beibehalten)

## UI/UX-Stabilität
- [ ] Menüs ausschließlich als Kontextmenü halten
- [ ] Ressourcen-HUD klein + direkt antippbar halten
- [x] Radialmenü mit Paging/zweiter Ebene für >10 Aktionen erweitern
- [x] Edge-Symbolik mit Fallback lesbar halten
- [ ] Reduced-Motion ohne Funktionsverlust sicherstellen

## Quality Gates vor jeder Erweiterung
- [x] `sanitizeState` gegen kaputte Inputs testen
- [x] Spawn/Sell/Auto-Craft-Konsistenz testen
- [x] Save-Load vor/nach Migration testen
- [ ] Drag/Long-Press/Tap-Konflikte testen
- [x] Auto-Tick-Stresstest ohne UI-Lag durchführen

## Nächste Refactor-Blöcke (priorisiert)
- [x] Facility-Modell auf `facilityInstanceId` umstellen
- [x] Auto-Craft auf aktive Instanzen binden
- [x] Orb-Layout-Sanitize auf dynamische Node-Keys umbauen
- [x] Persist-Strategie auf "changed-state only" härten
- [x] Radialmenü-Paging implementieren
- [x] `integrityCheck()` + `recoveryReport` ins System-Kontextmenü integrieren
