# Data Contract v3

## PlayerStateDocument

```json
{
  "schemaVersion": 3,
  "playerId": "local-player",
  "updatedAt": "2026-02-25T12:00:00.000Z",
  "state": {
    "version": 1,
    "tick": 0,
    "level": 1,
    "points": 0,
    "automation": {
      "workers": { "cloth": 0, "leather": 0, "wood": 0 },
      "autoCraft": { "bag_t1": false },
      "enabled": true
    },
    "ui": {
      "orbLayout": {},
      "selectedOrbId": null,
      "facilityInstances": [
        { "id": "facility:bag_t1:1", "recipeId": "bag_t1", "createdAt": "2026-02-25T12:00:00.000Z" }
      ],
      "nextFacilitySeq": 2,
      "viewMode": "none"
    },
    "inventory": {},
    "unlockedRecipes": [],
    "crafted": {},
    "stats": {
      "totalClicks": 0,
      "totalCrafts": 0,
      "totalPointsEarned": 0
    },
    "recoveryReport": null,
    "lastEvents": []
  }
}
```

## Migrationen
- `v1 -> v2`: `recoveryReport` hinzugefuegt.
- `v2 -> v3`: `ui.spawnedFacilityIds` nach `ui.facilityInstances` migriert, `ui.nextFacilitySeq` eingefuehrt.

## Invarianten
- `schemaVersion` ist aktuell `3`, `state.version` bleibt `1`.
- Numerische Felder sind nie negativ.
- `level` wird aus `points` abgeleitet.
- `ui.facilityInstances[*].id` folgt dem Muster `facility:<recipeId>:<seq>`.
- Nur Daten aus `crafting_clicker_singlefile.html` gelten als kanonisch.
